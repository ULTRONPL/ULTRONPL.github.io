#!/bin/bash
sudo ./xmrig
