#!/bin/bash
./xmrig
